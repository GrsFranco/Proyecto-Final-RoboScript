@echo off
java -jar lib\jflex-1.9.1.jar -d src\roboscript spec\Scanner.flex || exit /b 1
java -jar lib\java-cup-11b.jar -package roboscript -parser Parser -destdir src\roboscript spec\Parser.cup || exit /b 1
if not exist out mkdir out
javac -encoding UTF-8 -cp lib\java-cup-11b-runtime.jar -d out src\roboscript\*.java || exit /b 1
echo Compilacion exitosa. Ejecute: java -cp "out;lib\java-cup-11b-runtime.jar" roboscript.Main tests\valido1_flujo_normal.robot
