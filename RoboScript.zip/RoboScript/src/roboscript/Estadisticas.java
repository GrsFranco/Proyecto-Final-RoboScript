package roboscript;

/** Contadores semánticos acumulados por las acciones de la gramática CUP. */
public class Estadisticas {
    public int avanzar, retroceder, giroDerecha, giroIzquierda, seguirLinea;
    public int levantar, mover, soltar, velocidad;
    public int repetir, si, sino;
    public int tokens;

    public int movimientos()         { return avanzar + retroceder + mover + seguirLinea; }
    public int giros()               { return giroDerecha + giroIzquierda; }
    public int bloques()             { return repetir + si; }
    public int instruccionesSimples(){ return movimientos() + giros() + levantar + soltar + velocidad; }
    public int totalInstrucciones()  { return instruccionesSimples() + bloques(); }

    public void imprimir() {
        System.out.println("============ RESUMEN ESTADÍSTICO ============");
        System.out.printf("Tokens reconocidos ............ %d%n", tokens);
        System.out.printf("Total de instrucciones ........ %d  (simples: %d + bloques: %d)%n",
                          totalInstrucciones(), instruccionesSimples(), bloques());
        System.out.printf("Movimientos ................... %d  (AVANZAR %d, RETROCEDER %d, MOVER %d, SEGUIR LINEA %d)%n",
                          movimientos(), avanzar, retroceder, mover, seguirLinea);
        System.out.printf("Giros ......................... %d  (DERECHA %d, IZQUIERDA %d)%n",
                          giros(), giroDerecha, giroIzquierda);
        System.out.printf("Objetos levantados ............ %d%n", levantar);
        System.out.printf("Objetos soltados .............. %d%n", soltar);
        System.out.printf("Cambios de velocidad .......... %d%n", velocidad);
        System.out.printf("Bloques ....................... %d  (REPETIR %d, SI %d, de los cuales con SINO %d)%n",
                          bloques(), repetir, si, sino);
    }
}
